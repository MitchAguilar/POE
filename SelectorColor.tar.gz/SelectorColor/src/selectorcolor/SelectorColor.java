package selectorcolor;

import MotorLogico.Frame;

/**
 *
 * @author mitch
 */
public class SelectorColor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame a =  new Frame();
    }
    
}
